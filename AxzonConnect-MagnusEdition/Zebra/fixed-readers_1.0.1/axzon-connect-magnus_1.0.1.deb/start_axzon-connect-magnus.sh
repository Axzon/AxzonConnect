EXECUTABLE_NAME="axzon-connect-magnus"
python3 /apps/${EXECUTABLE_NAME}.py &

