EXECUTABLE_NAME="axzon-connect"
python3 /apps/${EXECUTABLE_NAME}.py &

